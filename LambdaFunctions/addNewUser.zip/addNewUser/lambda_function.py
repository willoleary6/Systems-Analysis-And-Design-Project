import json
import addNewUser


def lambda_handler(event, context):
    results = addNewUser.handler(event["username"], event["email"], event["password"])
    return {
        "statusCode": 200,
        "results": json.dumps(results)
    }
