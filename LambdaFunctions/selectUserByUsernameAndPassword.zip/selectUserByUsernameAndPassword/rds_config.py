#config file containing credentials for rds mysql instance
db_username = "willoleary6"
db_password = "sfSDHFDJFHEj23120-94cdpo"
db_name = "canoe"
rds_host = "canoe.crait7r8hupj.eu-west-1.rds.amazonaws.com"